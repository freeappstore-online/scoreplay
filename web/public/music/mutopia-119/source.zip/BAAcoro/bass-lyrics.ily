Vi -- va, vi -- va il no -- "stro Al" -- ci -- de!
go -- da, go -- da, go -- "da il"
Ni -- "lo in" que -- sto dì!

O -- gni spiag -- gia per lui ri -- de, 
o -- "gni af" -- fan -- no già spa -- rì;
o -- gni spiag -- gia per lui __ ri -- de, 
o -- "gni af" -- fan -- no già spa -- rì.
