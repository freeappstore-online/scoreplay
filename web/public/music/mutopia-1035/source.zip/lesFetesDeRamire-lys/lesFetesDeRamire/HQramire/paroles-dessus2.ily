
Vo -- lez, plai -- sirs, 
