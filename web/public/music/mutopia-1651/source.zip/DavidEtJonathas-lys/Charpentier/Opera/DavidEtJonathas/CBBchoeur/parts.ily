\piecePartSpecs #`((voix)
                   (basse-continue))